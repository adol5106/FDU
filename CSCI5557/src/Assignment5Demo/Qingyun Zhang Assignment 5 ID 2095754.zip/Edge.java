package Assignment5Demo;

public class Edge {
	  int u, v;
	  
	  public Edge(int u, int v) {
	    this.u = u;
	    this.v = v;
	  }
}
