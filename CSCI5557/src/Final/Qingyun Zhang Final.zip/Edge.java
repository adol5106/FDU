package Final;

public class Edge {
	public int u;
	public int v;
	  
	  public Edge(int u, int v) {
	    this.u = u;
	    this.v = v;
	  }
}
